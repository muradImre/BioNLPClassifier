import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import lightning as L
from lightning.pytorch.strategies import FSDPStrategy
from lightning.pytorch.plugins.precision import MixedPrecisionPlugin

from transformers import AutoTokenizer, AutoModelForSequenceClassification
from datasets import Dataset, DatasetDict
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, accuracy_score, confusion_matrix, roc_auc_score

file_path = '/teamspace/studios/this_studio/ChlorineClassifier/CHE_dataset.xlsx'
df = pd.read_excel(file_path)
df = df.dropna(subset=['abstract'])
df = df.iloc[101:]  

label_mapping = {'Relevant': 1, 'Irrelevant': 0}
df['label'] = df['Label'].map(label_mapping)


train_df, eval_df = train_test_split(df, test_size=0.2, random_state=42)


train_dataset = Dataset.from_pandas(train_df)
eval_dataset = Dataset.from_pandas(eval_df)
dataset = DatasetDict({
    'train': train_dataset,
    'eval': eval_dataset
})


model_name = 'stanford-crfm/BioMedLM'
tokenizer = AutoTokenizer.from_pretrained(model_name, add_prefix_space=True)


if tokenizer.pad_token is None:
    tokenizer.add_special_tokens({'pad_token': '[PAD]'})

model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)
model.resize_token_embeddings(len(tokenizer))


def preprocess_function(examples):
    combined_texts = [title + " " + abstract for title, abstract in zip(examples['short_title'], examples['abstract'])]
    return tokenizer(combined_texts, truncation=True, padding=True, max_length=512)

tokenized_dataset = dataset.map(preprocess_function, batched=True)


def compute_metrics(pred):
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='binary')
    accuracy = accuracy_score(labels, preds)
    conf_matrix = confusion_matrix(labels, preds)
    roc_auc = roc_auc_score(labels, pred.predictions[:, 1]) if len(set(labels)) > 1 else 0.5
    
    conf_matrix = conf_matrix.tolist()
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'confusion_matrix': conf_matrix,
        'roc_auc': roc_auc,
    }

# LightningModule
class ClassificationModel(L.LightningModule):
    def __init__(self, model_name, train_dataset, batch_size, learning_rate=2e-5):
        super().__init__()
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)
        self.train_dataset = train_dataset
        self.batch_size = batch_size
        self.learning_rate = learning_rate

        # Activation Checkpointing
        self.model.gradient_checkpointing_enable()

    def training_step(self, batch, batch_idx):
        outputs = self.model(**batch)
        loss = outputs.loss
        self.log('train_loss', loss, prog_bar=True)
        return loss

    def configure_optimizers(self):
        return torch.optim.AdamW(self.parameters(), lr=self.learning_rate)

    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True)

# LightningModule instance
classification_model = ClassificationModel(model_name=model_name, train_dataset=tokenized_dataset['train'], batch_size=16)

# Trainer with FSDP, Mixed Precision, and Activation Checkpointing
trainer = L.Trainer(
    accelerator="cuda",
    devices=4,
    strategy=FSDPStrategy(),
    max_epochs=10,
    precision="16-mixed",  # Mixed Precision Training
    #plugins=[MixedPrecisionPlugin(precision="bf16-mixed", device="cuda")],  # Additional specification -- mixed precision
)

# Train
trainer.fit(classification_model)


'''
For your specific code using the HuggingFace AutoModelForSequenceClassification, the single line self.model.gradient_checkpointing_enable() is all you need to enable Gradient Checkpointing. There is no need for additional edits or custom implementations in your code.

Here's how it applies to your code:

No Changes Required for Custom Layers: Your code uses AutoModelForSequenceClassification from HuggingFace, which fully supports Gradient Checkpointing out of the box. You don't need to worry about custom layers or models.
Compatibility: The combination of FSDP (Fully Sharded Data Parallel), Mixed Precision Training, and Gradient Checkpointing you've implemented is compatible. The HuggingFace Transformers library ensures that these techniques work well together without requiring extra code modifications.
Activation and Use: By calling self.model.gradient_checkpointing_enable() in the __init__ method of your ClassificationModel, Gradient Checkpointing is automatically applied to the entire model during training. There is no further action required.
In summary, for your specific setup and use case, that one line is sufficient. You do not need to modify any other part of your code to benefit from Gradient Checkpointing.
'''
