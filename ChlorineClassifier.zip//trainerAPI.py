#imports
from transformers import AutoTokenizer, AutoModelForSequenceClassification, TrainingArguments, Trainer, EarlyStoppingCallback
from datasets import Dataset, DatasetDict
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, accuracy_score, confusion_matrix, roc_auc_score

# Dataset
file_path = 'CHE_dataset.xlsx'
#second file path for CHS. Can run after (one at a time)
#file_path = 'ChlorineClassifier/CHS_dataset.xlsx'  

df = pd.read_excel(file_path) #if not excel file can use pd.read_json() or pd.read_csv()

# prepare
df = df.dropna(subset=['abstract'])

# testing - removing first 100 incase for training. When using call 'df = df.dropna(subset=['abstract'])' and 'df = df.iloc[0:100]'
df = df.iloc[101:]

label_mapping = {'Relevant': 1, 'Irrelevant': 0}
df['label'] = df['Label'].map(label_mapping)

# 80/20 split
train_df, eval_df = train_test_split(df, test_size=0.2, random_state=42)

# Convert to HuggingFace
train_dataset = Dataset.from_pandas(train_df)
eval_dataset = Dataset.from_pandas(eval_df)
dataset = DatasetDict({
    'train': train_dataset,
    'eval': eval_dataset
})

# Initialize tokenizer and model
model_name = 'stanford-crfm/BioMedLM'
tokenizer = AutoTokenizer.from_pretrained(model_name, add_prefix_space=True)

# Define the padding token
if tokenizer.pad_token is None:
    tokenizer.add_special_tokens({'pad_token': '[PAD]'})

model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)
model.resize_token_embeddings(len(tokenizer))

# Tokenize dataset
def preprocess_function(examples):
    combined_texts = [title + " " + abstract for title, abstract in zip(examples['short_title'], examples['abstract'])]
    return tokenizer(combined_texts, truncation=True, padding=True, max_length=512)

tokenized_dataset = dataset.map(preprocess_function, batched=True)

# Compute metrics
def compute_metrics(pred):
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='binary')
    accuracy = accuracy_score(labels, preds)
    conf_matrix = confusion_matrix(labels, preds)
    roc_auc = roc_auc_score(labels, pred.predictions[:, 1]) if len(set(labels)) > 1 else 0.5
    
    conf_matrix = conf_matrix.tolist()
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'confusion_matrix': conf_matrix,
        'roc_auc': roc_auc,
    }

# Train arguments ???
training_args = TrainingArguments(
    output_dir='./results',
    num_train_epochs=10,  # Based on stanford paper, change if needed
    per_device_train_batch_size=16, #if padding use 'Cannot handle batch sizes > 1 if no padding token is defined' arrises replace 16 with 1.
    per_device_eval_batch_size=16,  #if padding use 'Cannot handle batch sizes > 1 if no padding token is defined' arrises replace 16 with 1.
    warmup_steps=100,
    weight_decay=0.01,
    logging_dir='./logs',
    eval_strategy="steps",
    eval_steps=500,
    save_steps=500,
    save_total_limit=2,
    learning_rate=2e-5,
    gradient_accumulation_steps=2,
    fp16=True,
    logging_steps=100,
    load_best_model_at_end=True,
    metric_for_best_model="eval_loss",
    greater_is_better=False,
)

# Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset['train'],
    eval_dataset=tokenized_dataset['eval'],
    compute_metrics=compute_metrics,
    callbacks=[EarlyStoppingCallback(early_stopping_patience=3)]
)

# Training
trainer.train()

# Evaluate model
eval_results = trainer.evaluate()
print(f"Evaluation results: {eval_results}")

# confusion matrix
print("Confusion Matrix:")
print(eval_results['eval_confusion_matrix'])

# Save model and tokenizer
model.save_pretrained('./results')
tokenizer.save_pretrained('./results')