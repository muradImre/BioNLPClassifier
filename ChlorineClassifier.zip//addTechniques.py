import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import lightning as L
from lightning.pytorch.strategies import FSDPStrategy
from lightning.pytorch.plugins.precision import MixedPrecisionPlugin
#from lightning.pytorch.utilities.model_helpers import auto_wrap
from fairscale.nn import auto_wrap
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers.models.gpt2.modeling_gpt2 import GPT2Block  # Correctly import GPT2Block
from datasets import Dataset, DatasetDict
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, accuracy_score, confusion_matrix, roc_auc_score

# Dataset
file_path = '/teamspace/studios/this_studio/ChlorineClassifier/CHE_dataset.xlsx'
df = pd.read_excel(file_path)
df = df.dropna(subset=['abstract'])
df = df.iloc[101:]  # Removing first 100 entries if needed

label_mapping = {'Relevant': 1, 'Irrelevant': 0}
df['label'] = df['Label'].map(label_mapping)

# 80/20 split
train_df, eval_df = train_test_split(df, test_size=0.2, random_state=42)

# Convert to HuggingFace Dataset
train_dataset = Dataset.from_pandas(train_df)
eval_dataset = Dataset.from_pandas(eval_df)
dataset = DatasetDict({
    'train': train_dataset,
    'eval': eval_dataset
})

# Initialize tokenizer and model
model_name = 'stanford-crfm/BioMedLM'
tokenizer = AutoTokenizer.from_pretrained(model_name, add_prefix_space=True)

# Define the padding token
if tokenizer.pad_token is None:
    tokenizer.add_special_tokens({'pad_token': '[PAD]'})

model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)
model.resize_token_embeddings(len(tokenizer))

# Tokenize dataset
def preprocess_function(examples):
    combined_texts = [title + " " + abstract for title, abstract in zip(examples['short_title'], examples['abstract'])]
    return tokenizer(combined_texts, truncation=True, padding=True, max_length=512)

tokenized_dataset = dataset.map(preprocess_function, batched=True)

# Compute metrics
def compute_metrics(pred):
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='binary')
    accuracy = accuracy_score(labels, preds)
    conf_matrix = confusion_matrix(labels, preds)
    roc_auc = roc_auc_score(labels, pred.predictions[:, 1]) if len(set(labels)) > 1 else 0.5
    
    conf_matrix = conf_matrix.tolist()
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'confusion_matrix': conf_matrix,
        'roc_auc': roc_auc,
    }

from bitsandbytes.optim import Adam8bit

# LightningModule
class ClassificationModel(L.LightningModule):
    def __init__(self, model_name, train_dataset, batch_size, learning_rate=2e-5, accumulation_steps=8):
        super().__init__()
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)
        self.model = auto_wrap(self.model, GPT2Block)  # Wrap GPT2Block for FSDP
        self.train_dataset = train_dataset
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.accumulation_steps = accumulation_steps  #  accumulation steps

        #  Activation Checkpointing
        self.model.gradient_checkpointing_enable()

    def training_step(self, batch, batch_idx):
        outputs = self.model(**batch)
        loss = outputs.loss
        loss = loss / self.accumulation_steps  # Normalize loss
        self.log('train_loss', loss, prog_bar=True)
        return loss

    def configure_optimizers(self):
        optimizer = Adam8bit(self.parameters(), lr=self.learning_rate)
        return optimizer

    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True)

# Define FSDP strategy with optimized sharding
fsdp_strategy = FSDPStrategy(
    sharding_strategy="FULL_SHARD",  # Use full sharding for memory efficiency
    auto_wrap_policy=None,  # Set to None because you manually wrapped GPT2Block
)

classification_model = ClassificationModel(model_name=model_name, train_dataset=tokenized_dataset['train'], batch_size=1)

trainer = L.Trainer(
    accelerator="cuda",
    devices=4,
    strategy=fsdp_strategy,
    max_epochs=10,
    precision=16,  # Enable Mixed Precision Training
  # Additional specification for mixed precision
    accumulate_grad_batches=8  # Set gradient accumulation steps
)

trainer.fit(classification_model)

'''
Improvements:
Gradient Accumulation: 
Implemented by setting accumulation_steps=8, which helps simulate a larger batch size by accumulating gradients over multiple mini-batches. 
This is useful when you're constrained by GPU memory.
8-Bit Adam Optimizer: 
Introduced to significantly reduce memory usage by quantizing the optimizer states from 32-bit to 8-bit.
'''