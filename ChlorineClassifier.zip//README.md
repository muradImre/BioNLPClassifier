Chlorine Classifier using HuggingFace Trainer API

Installation

Run the following commands in your terminal to install the necessary packages: <br>
pip install "transformers[torch]" accelerate -U <br>
pip install datasets <br>
pip install pandas <br>
pip install scikit-learn <br>
pip install evaluate <br>

Usage

Set the File Path: <br>
File path in line 9 and 11 already have the correct path to the dataset file. Below the appropriate files for CHE and CHS: <br>
CHE Dataset: [Download CHE Dataset](https://ars.els-cdn.com/content/image/1-s2.0-S027323002200174X-mmc2.xlsx) <br>
CHS Dataset: [Download CHS Dataset](https://ars.els-cdn.com/content/image/1-s2.0-S027323002200174X-mmc3.xlsx)

Optimization

The provided settings in the trainer arguments are reasonable starting points and are commonly used in many transformer model training setups. However, optimization can be dataset-specific. You might need to experiment with: <br>
Learning Rate: Small adjustments can have significant effects. <br>
Batch Size: Adjust based on available memory and training stability. <br>
Number of Epochs: Monitor for overfitting and adjust accordingly. <br>
Warmup Steps: May need tuning based on learning rate and model stability. <br>
Feel free to adjust these parameters to better suit your specific dataset and computational resources.
